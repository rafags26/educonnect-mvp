import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMentoriaSchema, insertGroupSchema, insertMaterialSchema, insertEnrollmentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, nome, tipo } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email é obrigatório" });
      }

      let user = await storage.getUserByEmail(email);
      
      if (!user) {
        // Create new user
        const userData = insertUserSchema.parse({
          email,
          nome: nome || email.split('@')[0],
          tipo: tipo || 'aluno'
        });
        user = await storage.createUser(userData);
      } else {
        // Update existing user if name/type provided
        const updates: any = {};
        if (nome) updates.nome = nome;
        if (tipo) updates.tipo = tipo;
        if (Object.keys(updates).length > 0) {
          user = await storage.updateUser(user.id, updates) || user;
        }
      }

      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.put("/api/auth/profile/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { email, nome, tipo } = req.body;

      // Check if email is unique
      if (email) {
        const existingUser = await storage.getUserByEmail(email);
        if (existingUser && existingUser.id !== id) {
          return res.status(400).json({ message: "E-mail já cadastrado" });
        }
      }

      const updates = insertUserSchema.parse({ email, nome, tipo });
      const user = await storage.updateUser(id, updates);
      
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Mentorias routes
  app.get("/api/mentorias", async (req, res) => {
    try {
      const mentorias = await storage.getAllMentorias();
      res.json(mentorias);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/mentorias/:id/enroll", async (req, res) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;

      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }

      const mentoria = await storage.getMentoria(id);
      if (!mentoria) {
        return res.status(404).json({ message: "Mentoria não encontrada" });
      }

      if (mentoria.vagas <= 0) {
        return res.status(400).json({ message: "Sem vagas disponíveis" });
      }

      // Check if already enrolled
      const enrollments = await storage.getEnrollmentsByUser(userId);
      const alreadyEnrolled = enrollments.some(e => e.mentoriaId === id);
      
      if (alreadyEnrolled) {
        return res.status(400).json({ message: "Usuário já está inscrito nesta mentoria" });
      }

      // Create enrollment
      const enrollment = await storage.createEnrollment({ userId, mentoriaId: id });
      
      // Decrease vacancy
      await storage.updateMentoria(id, { vagas: mentoria.vagas - 1 });

      res.json(enrollment);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.delete("/api/mentorias/:id/enroll", async (req, res) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;

      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }

      const enrollments = await storage.getEnrollmentsByUser(userId);
      const enrollment = enrollments.find(e => e.mentoriaId === id);
      
      if (!enrollment) {
        return res.status(404).json({ message: "Inscrição não encontrada" });
      }

      // Delete enrollment
      await storage.deleteEnrollment(enrollment.id);
      
      // Increase vacancy
      const mentoria = await storage.getMentoria(id);
      if (mentoria) {
        await storage.updateMentoria(id, { vagas: mentoria.vagas + 1 });
      }

      res.json({ message: "Inscrição cancelada com sucesso" });
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.get("/api/enrollments/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const enrollments = await storage.getEnrollmentsByUser(userId);
      res.json(enrollments);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Groups routes
  app.get("/api/groups", async (req, res) => {
    try {
      const groups = await storage.getAllGroups();
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/groups", async (req, res) => {
    try {
      const { nome, userId } = req.body;
      
      if (!nome) {
        return res.status(400).json({ message: "Nome do grupo é obrigatório" });
      }

      const groupData = insertGroupSchema.parse({
        nome,
        membros: userId ? [userId] : []
      });

      const group = await storage.createGroup(groupData);
      res.json(group);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/groups/:id/join", async (req, res) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;

      if (!userId) {
        return res.status(400).json({ message: "ID do usuário é obrigatório" });
      }

      const group = await storage.getGroup(id);
      if (!group) {
        return res.status(404).json({ message: "Grupo não encontrado" });
      }

      const membros = group.membros || [];
      const isMember = membros.includes(userId);

      if (isMember) {
        // Remove from group
        const updatedMembros = membros.filter(m => m !== userId);
        const updatedGroup = await storage.updateGroup(id, { membros: updatedMembros });
        res.json(updatedGroup);
      } else {
        // Add to group
        const updatedMembros = [...membros, userId];
        const updatedGroup = await storage.updateGroup(id, { membros: updatedMembros });
        res.json(updatedGroup);
      }
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Materials routes
  app.get("/api/materials", async (req, res) => {
    try {
      const materials = await storage.getAllMaterials();
      res.json(materials);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  app.post("/api/materials", async (req, res) => {
    try {
      const { titulo, link, tags } = req.body;
      
      if (!titulo || !link) {
        return res.status(400).json({ message: "Título e link são obrigatórios" });
      }

      const materialData = insertMaterialSchema.parse({
        titulo,
        link,
        tags: tags || []
      });

      const material = await storage.createMaterial(materialData);
      res.json(material);
    } catch (error) {
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
