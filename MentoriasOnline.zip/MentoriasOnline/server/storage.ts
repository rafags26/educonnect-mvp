import { 
  type User, 
  type InsertUser,
  type Mentoria,
  type InsertMentoria,
  type Group,
  type InsertGroup,
  type Material,
  type InsertMaterial,
  type Enrollment,
  type InsertEnrollment
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Mentorias
  getAllMentorias(): Promise<Mentoria[]>;
  getMentoria(id: string): Promise<Mentoria | undefined>;
  createMentoria(mentoria: InsertMentoria): Promise<Mentoria>;
  updateMentoria(id: string, mentoria: Partial<InsertMentoria>): Promise<Mentoria | undefined>;
  deleteMentoria(id: string): Promise<void>;
  
  // Groups
  getAllGroups(): Promise<Group[]>;
  getGroup(id: string): Promise<Group | undefined>;
  createGroup(group: InsertGroup): Promise<Group>;
  updateGroup(id: string, group: Partial<InsertGroup>): Promise<Group | undefined>;
  deleteGroup(id: string): Promise<void>;
  
  // Materials
  getAllMaterials(): Promise<Material[]>;
  getMaterial(id: string): Promise<Material | undefined>;
  createMaterial(material: InsertMaterial): Promise<Material>;
  updateMaterial(id: string, material: Partial<InsertMaterial>): Promise<Material | undefined>;
  deleteMaterial(id: string): Promise<void>;
  
  // Enrollments
  getAllEnrollments(): Promise<Enrollment[]>;
  getEnrollment(id: string): Promise<Enrollment | undefined>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  deleteEnrollment(id: string): Promise<void>;
  getEnrollmentsByUser(userId: string): Promise<Enrollment[]>;
  getEnrollmentsByMentoria(mentoriaId: string): Promise<Enrollment[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private mentorias: Map<string, Mentoria>;
  private groups: Map<string, Group>;
  private materials: Map<string, Material>;
  private enrollments: Map<string, Enrollment>;

  constructor() {
    this.users = new Map();
    this.mentorias = new Map();
    this.groups = new Map();
    this.materials = new Map();
    this.enrollments = new Map();
    
    this.seedData();
  }

  private seedData() {
    // Seed mentorias
    const mentoriasSeed: InsertMentoria[] = [
      { titulo: 'HTML e CSS do zero', mentor: 'Ana Costa', data: '28/09 10h', vagas: 4 },
      { titulo: 'Introdução ao JavaScript', mentor: 'João Silva', data: '29/09 19h', vagas: 3 },
      { titulo: 'Produtividade com SCRUM', mentor: 'Maria Lima', data: '30/09 16h', vagas: 2 },
      { titulo: 'Como crescer na Internet', mentor: 'Rafa Gomes', data: '27/09 14h', vagas: 5 }
    ];

    mentoriasSeed.forEach(async (mentoria) => {
      await this.createMentoria(mentoria);
    });

    // Seed groups
    const groupsSeed: InsertGroup[] = [
      { nome: 'Front-end Iniciante', membros: [] },
      { nome: 'JS Avançado', membros: [] }
    ];

    groupsSeed.forEach(async (group) => {
      await this.createGroup(group);
    });

    // Seed materials
    const materialsSeed: InsertMaterial[] = [
      { titulo: 'Guia HTML5', link: 'https://developer.mozilla.org/pt-BR/docs/Web/HTML', tags: ['html'] },
      { titulo: 'CSS Tricks', link: 'https://css-tricks.com/', tags: ['css', 'ui'] }
    ];

    materialsSeed.forEach(async (material) => {
      await this.createMaterial(material);
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Mentorias
  async getAllMentorias(): Promise<Mentoria[]> {
    return Array.from(this.mentorias.values());
  }

  async getMentoria(id: string): Promise<Mentoria | undefined> {
    return this.mentorias.get(id);
  }

  async createMentoria(insertMentoria: InsertMentoria): Promise<Mentoria> {
    const id = randomUUID();
    const mentoria: Mentoria = { ...insertMentoria, id };
    this.mentorias.set(id, mentoria);
    return mentoria;
  }

  async updateMentoria(id: string, mentoriaData: Partial<InsertMentoria>): Promise<Mentoria | undefined> {
    const mentoria = this.mentorias.get(id);
    if (!mentoria) return undefined;
    const updatedMentoria = { ...mentoria, ...mentoriaData };
    this.mentorias.set(id, updatedMentoria);
    return updatedMentoria;
  }

  async deleteMentoria(id: string): Promise<void> {
    this.mentorias.delete(id);
  }

  // Groups
  async getAllGroups(): Promise<Group[]> {
    return Array.from(this.groups.values());
  }

  async getGroup(id: string): Promise<Group | undefined> {
    return this.groups.get(id);
  }

  async createGroup(insertGroup: InsertGroup): Promise<Group> {
    const id = randomUUID();
    const group: Group = { 
      ...insertGroup, 
      id,
      membros: insertGroup.membros || []
    };
    this.groups.set(id, group);
    return group;
  }

  async updateGroup(id: string, groupData: Partial<InsertGroup>): Promise<Group | undefined> {
    const group = this.groups.get(id);
    if (!group) return undefined;
    const updatedGroup = { ...group, ...groupData };
    this.groups.set(id, updatedGroup);
    return updatedGroup;
  }

  async deleteGroup(id: string): Promise<void> {
    this.groups.delete(id);
  }

  // Materials
  async getAllMaterials(): Promise<Material[]> {
    return Array.from(this.materials.values());
  }

  async getMaterial(id: string): Promise<Material | undefined> {
    return this.materials.get(id);
  }

  async createMaterial(insertMaterial: InsertMaterial): Promise<Material> {
    const id = randomUUID();
    const material: Material = { 
      ...insertMaterial, 
      id,
      tags: insertMaterial.tags || []
    };
    this.materials.set(id, material);
    return material;
  }

  async updateMaterial(id: string, materialData: Partial<InsertMaterial>): Promise<Material | undefined> {
    const material = this.materials.get(id);
    if (!material) return undefined;
    const updatedMaterial = { ...material, ...materialData };
    this.materials.set(id, updatedMaterial);
    return updatedMaterial;
  }

  async deleteMaterial(id: string): Promise<void> {
    this.materials.delete(id);
  }

  // Enrollments
  async getAllEnrollments(): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values());
  }

  async getEnrollment(id: string): Promise<Enrollment | undefined> {
    return this.enrollments.get(id);
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const id = randomUUID();
    const enrollment: Enrollment = { ...insertEnrollment, id };
    this.enrollments.set(id, enrollment);
    return enrollment;
  }

  async deleteEnrollment(id: string): Promise<void> {
    this.enrollments.delete(id);
  }

  async getEnrollmentsByUser(userId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(e => e.userId === userId);
  }

  async getEnrollmentsByMentoria(mentoriaId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(e => e.mentoriaId === mentoriaId);
  }
}

export const storage = new MemStorage();
