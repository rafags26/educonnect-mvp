# Overview

EduConnect is a Brazilian online mentorship platform that enables students and mentors to connect through scheduled mentoring sessions, study groups, and educational material sharing. The platform provides a comprehensive learning ecosystem with features for session enrollment, group collaboration, and resource management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query for server state management with custom hooks for authentication
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Development Server**: Custom Vite integration for SSR and development
- **Storage Interface**: Abstract storage interface pattern for data operations

## Data Storage
- **Database**: PostgreSQL with Neon Database serverless integration
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Tables**: Users, mentoring sessions (mentorias), study groups, educational materials, and enrollments
- **Client Storage**: localStorage for user session persistence and offline data caching

## Authentication & Authorization
- **Strategy**: Simple email-based authentication without passwords
- **Session Management**: Client-side session storage with localStorage
- **User Types**: Two role system - "aluno" (student) and "mentor"
- **Profile Management**: Users can update their profile information and switch roles

## API Design
- **Architecture**: RESTful API with Express.js
- **Endpoints**: CRUD operations for users, mentoring sessions, groups, materials, and enrollments
- **Data Validation**: Zod schemas for request/response validation
- **Error Handling**: Centralized error handling middleware
- **Response Format**: JSON responses with consistent error messaging

## Key Features
- **Mentoring System**: Session creation, enrollment management, and capacity tracking
- **Study Groups**: Group creation, member management, and collaboration features
- **Material Library**: Educational resource sharing with tagging and search functionality
- **User Management**: Profile management with role switching capabilities
- **Real-time Updates**: React Query for automatic data synchronization

## Development Environment
- **Build System**: Vite with TypeScript compilation and hot module replacement
- **Development Tools**: Replit-specific plugins for error overlay and development banner
- **Path Aliases**: Configured aliases for clean import statements (@, @shared, @assets)
- **Code Quality**: TypeScript strict mode with comprehensive type checking

## Deployment Architecture
- **Build Process**: Separate frontend (Vite) and backend (esbuild) build processes
- **Static Assets**: Frontend builds to dist/public for static serving
- **Server Bundle**: Backend bundles to dist/index.js for production deployment
- **Environment**: Supports both development and production configurations

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe database operations and schema management
- **Drizzle Kit**: Database migration and introspection tools

## UI & Styling
- **Radix UI**: Comprehensive set of accessible React components
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Utility for managing component variants

## Development & Build Tools
- **Vite**: Frontend build tool with hot module replacement
- **esbuild**: Fast JavaScript bundler for backend compilation
- **TypeScript**: Type-safe JavaScript development
- **PostCSS**: CSS processing with Tailwind integration

## React Ecosystem
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form state management and validation
- **Wouter**: Lightweight routing solution
- **Zod**: Runtime type validation and schema definition

## Development Enhancement
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Code navigation enhancement
- **@replit/vite-plugin-dev-banner**: Development environment indicator

## Utilities & Helpers
- **clsx & tailwind-merge**: Conditional CSS class management
- **date-fns**: Date manipulation and formatting
- **nanoid**: Unique ID generation for client-side operations