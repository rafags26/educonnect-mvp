import { useState } from "react";
import Header from "@/components/header";
import MentoriasTab from "@/components/mentorias-tab";
import GruposTab from "@/components/grupos-tab";
import MateriaisTab from "@/components/materiais-tab";
import PerfilTab from "@/components/perfil-tab";
import AuthDialog from "@/components/auth-dialog";
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const [activeTab, setActiveTab] = useState("mentorias");
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const { user, login, logout } = useAuth();

  const handleAuthClick = () => {
    if (user) {
      setActiveTab("perfil");
    } else {
      setShowAuthDialog(true);
    }
  };

  const handleLogin = async (email: string, nome?: string, tipo?: string) => {
    const success = await login(email, nome, tipo);
    if (success) {
      setShowAuthDialog(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <Header 
        user={user}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onAuthClick={handleAuthClick}
      />
      
      <main className="container mx-auto px-4 lg:px-8 py-8">
        {activeTab === "mentorias" && <MentoriasTab user={user} />}
        {activeTab === "grupos" && <GruposTab user={user} />}
        {activeTab === "materiais" && <MateriaisTab user={user} />}
        {activeTab === "perfil" && <PerfilTab user={user} onLogout={logout} />}
      </main>

      <AuthDialog 
        open={showAuthDialog}
        onOpenChange={setShowAuthDialog}
        onLogin={handleLogin}
      />
    </div>
  );
}
