import { useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Load user from localStorage on mount
    const savedUser = localStorage.getItem('educonnect_user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        localStorage.removeItem('educonnect_user');
      }
    }
    setLoading(false);

    // Listen for user updates
    const handleUserUpdated = (event: CustomEvent) => {
      setUser(event.detail);
    };

    window.addEventListener('userUpdated', handleUserUpdated as EventListener);

    return () => {
      window.removeEventListener('userUpdated', handleUserUpdated as EventListener);
    };
  }, []);

  const login = async (email: string, nome?: string, tipo?: string): Promise<boolean> => {
    try {
      const response = await apiRequest("POST", "/api/auth/login", {
        email,
        nome,
        tipo
      });
      
      const userData = await response.json();
      setUser(userData);
      localStorage.setItem('educonnect_user', JSON.stringify(userData));
      
      return true;
    } catch (error: any) {
      toast({
        title: "Erro no login",
        description: error.message || "Erro ao fazer login",
        variant: "destructive"
      });
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('educonnect_user');
  };

  return {
    user,
    loading,
    login,
    logout
  };
}
