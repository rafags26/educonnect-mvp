// Client-side storage utilities (keeping for compatibility if needed)
export const storage = {
  get: <T>(key: string, fallback: T): T => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  },
  
  set: <T>(key: string, value: T): void => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
    }
  },
  
  remove: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Failed to remove from localStorage:', error);
    }
  }
};

export const STORAGE_KEYS = {
  user: 'educonnect_user',
  mentorias: 'educonnect_mentorias',
  groups: 'educonnect_groups',
  materials: 'educonnect_materials',
  enrollments: 'educonnect_enrollments'
} as const;
