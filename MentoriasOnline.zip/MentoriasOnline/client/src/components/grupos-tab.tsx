import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Users, UserPlus, UserMinus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User, Group } from "@shared/schema";

interface GruposTabProps {
  user: User | null;
}

export default function GruposTab({ user }: GruposTabProps) {
  const [groupName, setGroupName] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: groups = [], isLoading } = useQuery<Group[]>({
    queryKey: ["/api/groups"],
  });

  const createGroupMutation = useMutation({
    mutationFn: async (nome: string) => {
      return await apiRequest("POST", "/api/groups", { nome, userId: user?.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      setGroupName("");
      toast({ title: "Grupo criado!", description: "Grupo criado com sucesso." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Erro", 
        description: error.message || "Erro ao criar grupo",
        variant: "destructive" 
      });
    },
  });

  const toggleGroupMutation = useMutation({
    mutationFn: async (groupId: string) => {
      return await apiRequest("POST", `/api/groups/${groupId}/join`, { userId: user?.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Erro", 
        description: error.message || "Erro ao entrar/sair do grupo",
        variant: "destructive" 
      });
    },
  });

  const handleCreateGroup = () => {
    if (!groupName.trim()) {
      toast({ title: "Erro", description: "Dê um nome ao grupo", variant: "destructive" });
      return;
    }
    createGroupMutation.mutate(groupName.trim());
  };

  const handleToggleGroup = (groupId: string) => {
    if (!user) {
      toast({ title: "Erro", description: "Entre para participar de grupos", variant: "destructive" });
      return;
    }
    toggleGroupMutation.mutate(groupId);
  };

  const isMember = (group: Group) => {
    return user && group.membros && group.membros.includes(user.id);
  };

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="space-y-2">
          <div className="h-8 bg-muted animate-pulse rounded"></div>
          <div className="h-4 bg-muted animate-pulse rounded w-2/3"></div>
        </div>
        <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
          <div className="h-10 bg-muted animate-pulse rounded"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="bg-card rounded-lg border border-border p-6 shadow-sm">
              <div className="space-y-4">
                <div className="h-6 bg-muted animate-pulse rounded"></div>
                <div className="h-4 bg-muted animate-pulse rounded w-3/4"></div>
                <div className="h-10 bg-muted animate-pulse rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <section className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Grupos de Estudo</h2>
        <p className="text-muted-foreground">Conecte-se com outros estudantes e aprenda em comunidade</p>
      </div>

      {/* Create Group Card */}
      <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
        <div className="space-y-4">
          <h3 className="font-semibold text-lg">Criar Novo Grupo</h3>
          <div className="flex flex-col md:flex-row gap-4">
            <input 
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 flex-1" 
              placeholder="Nome do grupo (ex.: Front-end Iniciante)" 
              data-testid="input-group-name"
            />
            <button 
              onClick={handleCreateGroup}
              disabled={createGroupMutation.isPending}
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
              data-testid="button-create-group"
            >
              <Plus className="w-4 h-4 mr-2" />
              Criar grupo
            </button>
          </div>
        </div>
      </div>

      {/* Groups Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {groups.map((group) => {
          const memberCount = group.membros?.length || 0;
          const userIsMember = isMember(group);
          
          return (
            <div key={group.id} className="bg-card rounded-lg border border-border p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <h3 className="font-semibold text-lg leading-tight" data-testid={`text-group-name-${group.id}`}>
                    {group.nome}
                  </h3>
                  <span className="inline-flex items-center rounded-full bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-600/20">
                    {memberCount} membro(s)
                  </span>
                </div>
                
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>Grupo de estudos colaborativo</span>
                </div>
                
                <button 
                  onClick={() => handleToggleGroup(group.id)}
                  disabled={toggleGroupMutation.isPending}
                  className={`w-full inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 ${
                    userIsMember
                      ? "border border-input bg-background hover:bg-accent hover:text-accent-foreground text-destructive hover:bg-destructive/5"
                      : "bg-primary text-primary-foreground hover:bg-primary/90"
                  }`}
                  data-testid={`button-${userIsMember ? 'leave' : 'join'}-group-${group.id}`}
                >
                  {userIsMember ? (
                    <>
                      <UserMinus className="w-4 h-4 mr-2" />
                      Sair do grupo
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4 mr-2" />
                      Entrar no grupo
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {groups.length === 0 && (
        <div className="bg-muted/50 rounded-lg border border-dashed border-border p-8 text-center">
          <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Nenhum grupo disponível ainda.</p>
        </div>
      )}
    </section>
  );
}
