import { GraduationCap, Users, Users2, BookOpen, User } from "lucide-react";
import type { User as UserType } from "@shared/schema";

interface HeaderProps {
  user: UserType | null;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onAuthClick: () => void;
}

export default function Header({ user, activeTab, onTabChange, onAuthClick }: HeaderProps) {
  const tabs = [
    { id: "mentorias", label: "Mentorias", icon: Users },
    { id: "grupos", label: "Grupos", icon: Users2 },
    { id: "materiais", label: "Materiais", icon: BookOpen },
    { id: "perfil", label: "Perfil", icon: User },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg gradient-bg flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-bold text-foreground">EduConnect</h1>
            </div>
            
            <nav className="hidden md:flex">
              <ul className="flex items-center space-x-1">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <li key={tab.id}>
                      <button
                        onClick={() => onTabChange(tab.id)}
                        className={`inline-flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-md transition-colors hover:bg-muted hover:text-muted-foreground ${
                          activeTab === tab.id 
                            ? "bg-accent text-accent-foreground" 
                            : ""
                        }`}
                        data-testid={`nav-${tab.id}`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{tab.label}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <span className="hidden md:block text-sm text-muted-foreground">
              {user 
                ? `Olá, ${user.nome} (${user.tipo})` 
                : "Você não está autenticado"
              }
            </span>
            <button 
              onClick={onAuthClick}
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
              data-testid="button-auth"
            >
              {user ? "Perfil" : "Entrar"}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
