import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Save, LogOut, Info } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

interface PerfilTabProps {
  user: User | null;
  onLogout: () => void;
}

export default function PerfilTab({ user, onLogout }: PerfilTabProps) {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [tipo, setTipo] = useState<"aluno" | "mentor">("aluno");
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      setNome(user.nome || "");
      setEmail(user.email || "");
      setTipo(user.tipo as "aluno" | "mentor" || "aluno");
    }
  }, [user]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: { nome: string; email: string; tipo: string }) => {
      if (!user) throw new Error("Usuário não encontrado");
      return await apiRequest("PUT", `/api/auth/profile/${user.id}`, data);
    },
    onSuccess: () => {
      toast({ title: "Perfil salvo!", description: "Suas informações foram atualizadas." });
      // Update local storage
      if (user) {
        const updatedUser = { ...user, nome, email, tipo };
        localStorage.setItem('educonnect_user', JSON.stringify(updatedUser));
        // Trigger a custom event to update auth state
        window.dispatchEvent(new CustomEvent('userUpdated', { detail: updatedUser }));
      }
    },
    onError: (error: any) => {
      toast({ 
        title: "Erro", 
        description: error.message || "Erro ao salvar perfil",
        variant: "destructive" 
      });
    },
  });

  const handleSaveProfile = () => {
    if (!email.trim()) {
      toast({ title: "Erro", description: "Informe e-mail", variant: "destructive" });
      return;
    }

    updateProfileMutation.mutate({ nome, email: email.trim(), tipo });
  };

  const handleLogout = () => {
    onLogout();
    toast({ title: "Você saiu", description: "Deslogado com sucesso." });
  };

  return (
    <section className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Meu Perfil</h2>
        <p className="text-muted-foreground">Gerencie suas informações pessoais e preferências</p>
      </div>

      {/* Profile Card */}
      <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label htmlFor="perfilNome" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                Nome
              </label>
              <input 
                id="perfilNome"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
                placeholder="Seu nome" 
                data-testid="input-profile-nome"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="perfilEmail" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                E-mail
              </label>
              <input 
                id="perfilEmail"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
                placeholder="Seu e-mail (único)" 
                data-testid="input-profile-email"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <label htmlFor="perfilTipo" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
              Tipo de Usuário
            </label>
            <select 
              id="perfilTipo"
              value={tipo}
              onChange={(e) => setTipo(e.target.value as "aluno" | "mentor")}
              className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              data-testid="select-profile-tipo"
            >
              <option value="aluno">Aluno</option>
              <option value="mentor">Mentor</option>
            </select>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4">
            <button 
              onClick={handleSaveProfile}
              disabled={updateProfileMutation.isPending}
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
              data-testid="button-save-profile"
            >
              <Save className="w-4 h-4 mr-2" />
              Salvar perfil
            </button>
            <button 
              onClick={handleLogout}
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2 text-destructive hover:bg-destructive/5"
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </button>
          </div>
        </div>
      </div>

      {/* Info Card */}
      <div className="bg-muted/50 rounded-lg border border-dashed border-border p-6">
        <div className="flex items-start space-x-3">
          <Info className="w-5 h-5 text-muted-foreground mt-0.5" />
          <div className="space-y-1">
            <p className="text-sm font-medium">Sobre o MVP</p>
            <p className="text-sm text-muted-foreground">No MVP, o login é feito por e-mail (sem senha) e fica salvo no navegador.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
