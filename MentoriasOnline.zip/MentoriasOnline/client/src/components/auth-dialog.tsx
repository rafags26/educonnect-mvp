import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

interface AuthDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onLogin: (email: string, nome?: string, tipo?: string) => Promise<void>;
}

export default function AuthDialog({ open, onOpenChange, onLogin }: AuthDialogProps) {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [tipo, setTipo] = useState<"aluno" | "mentor">("aluno");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) {
      return;
    }

    setLoading(true);
    try {
      await onLogin(email.trim(), nome.trim() || undefined, tipo);
      // Reset form
      setNome("");
      setEmail("");
      setTipo("aluno");
    } catch (error) {
      // Error handling is done in the parent component
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    onOpenChange(false);
    // Reset form
    setNome("");
    setEmail("");
    setTipo("aluno");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-full max-w-md" data-testid="dialog-auth">
        <DialogHeader>
          <DialogTitle>Entrar / Cadastrar</DialogTitle>
          <DialogDescription>
            Acesse sua conta ou crie uma nova
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="authNome" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
              Nome
            </label>
            <input 
              id="authNome"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
              placeholder="Seu nome" 
              data-testid="input-auth-nome"
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="authEmail" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
              E-mail
            </label>
            <input 
              id="authEmail"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
              placeholder="Seu e-mail (ex.: user@fae.edu.br)" 
              required
              data-testid="input-auth-email"
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="authTipo" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
              Tipo de Usuário
            </label>
            <select 
              id="authTipo"
              value={tipo}
              onChange={(e) => setTipo(e.target.value as "aluno" | "mentor")}
              className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              data-testid="select-auth-tipo"
            >
              <option value="aluno">Aluno</option>
              <option value="mentor">Mentor</option>
            </select>
          </div>
          
          <div className="flex flex-col md:flex-row gap-3 pt-4">
            <button 
              type="submit"
              disabled={loading}
              className="flex-1 inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
              data-testid="button-auth-confirm"
            >
              {loading ? "Carregando..." : "Confirmar"}
            </button>
            <button 
              type="button"
              onClick={handleCancel}
              className="flex-1 inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2"
              data-testid="button-auth-cancel"
            >
              Cancelar
            </button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
