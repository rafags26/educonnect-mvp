import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Search, Filter, X, CalendarPlus, CalendarX, Calendar, User as UserIcon } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User, Mentoria, Enrollment } from "@shared/schema";

interface MentoriasTabProps {
  user: User | null;
}

export default function MentoriasTab({ user }: MentoriasTabProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: mentorias = [], isLoading: mentoriasLoading } = useQuery<Mentoria[]>({
    queryKey: ["/api/mentorias"],
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments", user?.id],
    enabled: !!user?.id,
  });

  const enrollMutation = useMutation({
    mutationFn: async (mentoriaId: string) => {
      return await apiRequest("POST", `/api/mentorias/${mentoriaId}/enroll`, { userId: user?.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mentorias"] });
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments", user?.id] });
      toast({ title: "Inscrição confirmada!", description: "Você foi inscrito na mentoria." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Erro", 
        description: error.message || "Erro ao se inscrever na mentoria",
        variant: "destructive" 
      });
    },
  });

  const unenrollMutation = useMutation({
    mutationFn: async (mentoriaId: string) => {
      return await apiRequest("DELETE", `/api/mentorias/${mentoriaId}/enroll`, { userId: user?.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mentorias"] });
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments", user?.id] });
      toast({ title: "Inscrição cancelada", description: "Sua inscrição foi cancelada." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Erro", 
        description: error.message || "Erro ao cancelar inscrição",
        variant: "destructive" 
      });
    },
  });

  const filteredMentorias = mentorias.filter(mentoria =>
    mentoria.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    mentoria.mentor.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const myEnrollments = enrollments.map(enrollment => {
    const mentoria = mentorias.find(m => m.id === enrollment.mentoriaId);
    return { enrollment, mentoria };
  }).filter(item => item.mentoria);

  const handleEnroll = (mentoriaId: string) => {
    if (!user) {
      toast({ title: "Erro", description: "Entre para agendar mentorias", variant: "destructive" });
      return;
    }
    enrollMutation.mutate(mentoriaId);
  };

  const handleUnenroll = (mentoriaId: string) => {
    unenrollMutation.mutate(mentoriaId);
  };

  const isEnrolled = (mentoriaId: string) => {
    return enrollments.some(e => e.mentoriaId === mentoriaId);
  };

  if (mentoriasLoading) {
    return (
      <div className="space-y-8">
        <div className="space-y-2">
          <div className="h-8 bg-muted animate-pulse rounded"></div>
          <div className="h-4 bg-muted animate-pulse rounded w-2/3"></div>
        </div>
        <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
          <div className="h-10 bg-muted animate-pulse rounded"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-card rounded-lg border border-border p-6 shadow-sm">
              <div className="space-y-4">
                <div className="h-6 bg-muted animate-pulse rounded"></div>
                <div className="h-4 bg-muted animate-pulse rounded w-3/4"></div>
                <div className="h-10 bg-muted animate-pulse rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <section className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Mentorias Disponíveis</h2>
        <p className="text-muted-foreground">Encontre mentores especialistas para acelerar seu aprendizado</p>
      </div>

      {/* Search and Filter Card */}
      <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-10 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
              placeholder="Buscar por título ou mentor..." 
              data-testid="input-search-mentoria"
            />
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setSearchTerm("")}
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2"
              data-testid="button-clear-filter"
            >
              <X className="w-4 h-4 mr-2" />
              Limpar
            </button>
          </div>
        </div>
      </div>

      {/* Mentorias Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMentorias.map((mentoria) => {
          const enrolled = isEnrolled(mentoria.id);
          const vacancyColor = mentoria.vagas > 3 ? 'green' : mentoria.vagas > 0 ? 'yellow' : 'red';
          
          return (
            <div key={mentoria.id} className="bg-card rounded-lg border border-border p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <h3 className="font-semibold text-lg leading-tight" data-testid={`text-mentoria-title-${mentoria.id}`}>
                    {mentoria.titulo}
                  </h3>
                  <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ring-1 ring-inset ${
                    vacancyColor === 'green' 
                      ? 'bg-green-50 text-green-700 ring-green-600/20' 
                      : vacancyColor === 'yellow'
                      ? 'bg-yellow-50 text-yellow-700 ring-yellow-600/20'
                      : 'bg-red-50 text-red-700 ring-red-600/20'
                  }`}>
                    {mentoria.vagas > 0 ? `${mentoria.vagas} vaga(s)` : 'Esgotado'}
                  </span>
                </div>
                
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-2">
                    <UserIcon className="w-4 h-4" />
                    <span><strong>Mentor:</strong> {mentoria.mentor}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4" />
                    <span><strong>Data:</strong> {mentoria.data}</span>
                  </div>
                </div>
                
                <button 
                  onClick={() => enrolled ? handleUnenroll(mentoria.id) : handleEnroll(mentoria.id)}
                  disabled={(mentoria.vagas <= 0 && !enrolled) || enrollMutation.isPending || unenrollMutation.isPending}
                  className={`w-full inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 ${
                    enrolled
                      ? "border border-input bg-background hover:bg-accent hover:text-accent-foreground text-destructive hover:bg-destructive/5"
                      : "bg-primary text-primary-foreground hover:bg-primary/90"
                  }`}
                  data-testid={`button-${enrolled ? 'unenroll' : 'enroll'}-${mentoria.id}`}
                >
                  {enrolled ? (
                    <>
                      <CalendarX className="w-4 h-4 mr-2" />
                      Cancelar
                    </>
                  ) : (
                    <>
                      <CalendarPlus className="w-4 h-4 mr-2" />
                      Agendar
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredMentorias.length === 0 && (
        <div className="bg-muted/50 rounded-lg border border-dashed border-border p-8 text-center">
          <Search className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Nenhuma mentoria encontrada.</p>
        </div>
      )}

      {/* Minhas Mentorias Section */}
      <div className="space-y-4">
        <h3 className="text-2xl font-semibold">Minhas Mentorias</h3>
        <div className="space-y-4">
          {!user ? (
            <div className="bg-muted/50 rounded-lg border border-dashed border-border p-8 text-center">
              <CalendarX className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Entre para ver suas inscrições.</p>
            </div>
          ) : myEnrollments.length === 0 ? (
            <div className="bg-muted/50 rounded-lg border border-dashed border-border p-8 text-center">
              <CalendarX className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nenhuma inscrição ainda.</p>
            </div>
          ) : (
            myEnrollments.map(({ enrollment, mentoria }) => (
              <div key={enrollment.id} className="bg-card rounded-lg border border-border p-6 shadow-sm">
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <h3 className="font-semibold text-lg leading-tight">{mentoria!.titulo}</h3>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-2">
                      <UserIcon className="w-4 h-4" />
                      <span><strong>Mentor:</strong> {mentoria!.mentor}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4" />
                      <span><strong>Data:</strong> {mentoria!.data}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleUnenroll(mentoria!.id)}
                      disabled={unenrollMutation.isPending}
                      className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2 text-destructive hover:bg-destructive/5"
                      data-testid={`button-cancel-${mentoria!.id}`}
                    >
                      <CalendarX className="w-4 h-4 mr-2" />
                      Cancelar
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
