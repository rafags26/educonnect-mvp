import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Search, Filter, X, ExternalLink } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User, Material } from "@shared/schema";

interface MateriaisTabProps {
  user: User | null;
}

export default function MateriaisTab({ user }: MateriaisTabProps) {
  const [titulo, setTitulo] = useState("");
  const [link, setLink] = useState("");
  const [tagsInput, setTagsInput] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: materials = [], isLoading } = useQuery<Material[]>({
    queryKey: ["/api/materials"],
  });

  const createMaterialMutation = useMutation({
    mutationFn: async (data: { titulo: string; link: string; tags: string[] }) => {
      return await apiRequest("POST", "/api/materials", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/materials"] });
      setTitulo("");
      setLink("");
      setTagsInput("");
      toast({ title: "Material adicionado!", description: "Material adicionado com sucesso." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Erro", 
        description: error.message || "Erro ao adicionar material",
        variant: "destructive" 
      });
    },
  });

  const handleAddMaterial = () => {
    if (!user) {
      toast({ title: "Erro", description: "Entre para adicionar materiais", variant: "destructive" });
      return;
    }

    if (!titulo.trim() || !link.trim()) {
      toast({ title: "Erro", description: "Preencha título e link", variant: "destructive" });
      return;
    }

    const tags = tagsInput.split(",").map(t => t.trim()).filter(Boolean);
    createMaterialMutation.mutate({ titulo: titulo.trim(), link: link.trim(), tags });
  };

  const filteredMaterials = materials.filter(material =>
    material.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    material.link.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (material.tags && material.tags.some(tag => 
      tag.toLowerCase().includes(searchTerm.toLowerCase())
    ))
  );

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="space-y-2">
          <div className="h-8 bg-muted animate-pulse rounded"></div>
          <div className="h-4 bg-muted animate-pulse rounded w-2/3"></div>
        </div>
        <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
          <div className="space-y-4">
            <div className="h-6 bg-muted animate-pulse rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="h-10 bg-muted animate-pulse rounded"></div>
              <div className="h-10 bg-muted animate-pulse rounded"></div>
              <div className="h-10 bg-muted animate-pulse rounded"></div>
            </div>
          </div>
        </div>
        <div className="space-y-4">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="bg-card rounded-lg border border-border p-6 shadow-sm">
              <div className="space-y-4">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3"></div>
                <div className="h-4 bg-muted animate-pulse rounded w-2/3"></div>
                <div className="h-4 bg-muted animate-pulse rounded w-1/4"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <section className="space-y-8">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Biblioteca de Materiais</h2>
        <p className="text-muted-foreground">Compartilhe e descubra recursos de aprendizado</p>
      </div>

      {/* Add Material Card */}
      <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
        <div className="space-y-4">
          <h3 className="font-semibold text-lg">Adicionar Material</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input 
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
              placeholder="Título do material" 
              data-testid="input-material-titulo"
            />
            <input 
              value={link}
              onChange={(e) => setLink(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
              placeholder="URL (https://...)" 
              data-testid="input-material-link"
            />
            <input 
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
              placeholder="tags separadas por vírgula (html,css)" 
              data-testid="input-material-tags"
            />
          </div>
          <button 
            onClick={handleAddMaterial}
            disabled={createMaterialMutation.isPending}
            className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
            data-testid="button-add-material"
          >
            <Plus className="w-4 h-4 mr-2" />
            Adicionar
          </button>
        </div>
      </div>

      {/* Filter Materials Card */}
      <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-10 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" 
              placeholder="Buscar por título/link/tag..." 
              data-testid="input-search-material"
            />
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setSearchTerm("")}
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2"
              data-testid="button-clear-material-filter"
            >
              <X className="w-4 h-4 mr-2" />
              Limpar
            </button>
          </div>
        </div>
      </div>

      {/* Materials List */}
      <div className="space-y-4">
        {filteredMaterials.length === 0 ? (
          <div className="bg-muted/50 rounded-lg border border-dashed border-border p-8 text-center">
            <Search className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Nenhum material encontrado.</p>
          </div>
        ) : (
          filteredMaterials.map((material) => (
            <div key={material.id} className="bg-card rounded-lg border border-border p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <h3 className="font-semibold text-lg leading-tight" data-testid={`text-material-title-${material.id}`}>
                    {material.titulo}
                  </h3>
                  <ExternalLink className="w-5 h-5 text-muted-foreground" />
                </div>
                
                <div className="space-y-2">
                  <a 
                    href={material.link} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline text-sm break-all"
                    data-testid={`link-material-${material.id}`}
                  >
                    {material.link}
                  </a>
                  {material.tags && material.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {material.tags.map((tag) => (
                        <span 
                          key={tag}
                          className="inline-flex items-center rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground"
                          data-testid={`tag-${tag}`}
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}
